.. _developers:

.. note::

   We welcome everyone intersted to contribute to SQcircuit!


===========
Developers
===========

| `Taha Rajabzadeh <https://linqs.stanford.edu/person/taha-rajabzadeh>`_ (Stanford University)
| `Amir Safavi-Naieni  <https://linqs.stanford.edu/person/amir-safavi-naeini>`_ (Stanford University)


.. _developers-contributors:

============
Contributors
============


| **Yudan Guo** (Stanford University) - Bug hunter
| **Zhaoyou Wang** (Stanford University) - Bug hunter
| **Nathan Lee** (Stanford University) - Bug hunter
| **Takuma Makihara** (Stanford University) - Bug hunter