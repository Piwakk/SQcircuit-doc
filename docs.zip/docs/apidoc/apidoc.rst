.. _apidoc:

*****************
API documentation
*****************

.. toctree::
   :maxdepth: 2

   elements.rst
